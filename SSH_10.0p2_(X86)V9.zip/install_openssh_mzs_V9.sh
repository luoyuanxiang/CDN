#!/bin/bash
set -euo pipefail

# ------------------------------------------------------
# OpenSSH 离线安装脚本 v1.0.3
# 作者：omanik
# 日期：2025-04-23
# 功能：兼容检查、版本检测、自动回滚、日志机制、备份验证、SELinux 检测和禁用
# ------------------------------------------------------

# 日志配置
LOGFILE="$(pwd)/openssh_install_$(date +%Y%m%d%H%M%S).log"
exec > >(tee -a "$LOGFILE") 2>&1

log() {
    echo -e "\e[36m[$(date +'%Y-%m-%d %H:%M:%S')] $*\e[0m"
}

error_exit() {
    echo -e "\e[31m错误：$*\e[0m"
    exit 1
}

# 检查关键命令是否可用
check_commands() {
    for cmd in tar rpm yum systemctl getfacl setfacl; do
        if ! command -v $cmd >/dev/null; then
            error_exit "必需命令 $cmd 不可用"
        fi
    done
}

# 0. 欢迎提示与兼容性声明
echo "------------------------------------------------------"
echo -e "\e[34m🛠  欢迎使用 OpenSSH 离线安装脚本（v1.0.4）\e[0m"
echo "------------------------------------------------------"
echo -e "\e[36m✔  支持系统：\e[0m"
echo -e "\e[32m  - CentOS 7.x（内核 3.10.0-）"
echo -e "  - CentOS 8.x（内核 4.18.0-）"
echo -e "  - Rocky Linux 9.x（内核 5.14.0-）"
echo -e "  - Alibaba Cloud Linux 3（内核 5.10.0-）"
echo -e "  - 其他 RedHat 系发行版请自测兼容性\e[0m"
echo -e "\e[36m✔  架构要求：\e[0m \e[32mx86_64\e[0m"
echo
read -p $'\e[33m是否继续安装？(y/n): \e[0m' choice
[[ ! "$choice" =~ ^[Yy]$ ]] && error_exit "已取消安装。"

check_commands

# 1. 解压安装包
log "解压 SSH 安装包..."
TAR_FILE="SSH_10.0p2-rpm.tar.gz"
[[ ! -f "$TAR_FILE" ]] && error_exit "$TAR_FILE 不存在！"
mkdir -p ./openssh_rpms
tar -xzf "$TAR_FILE" -C ./openssh_rpms
cd ./openssh_rpms

# 2. 系统检查
log "执行系统环境检查..."
OS_ID=$(grep "^ID=" /etc/os-release | cut -d= -f2 | tr -d '"')
OS_VERSION_ID=$(grep "^VERSION_ID=" /etc/os-release | cut -d= -f2 | tr -d '"')
CPU_ARCH=$(uname -m)
KERNEL_VER=$(uname -r)

[[ "$CPU_ARCH" != "x86_64" ]] && error_exit "当前架构为 $CPU_ARCH，仅支持 x86_64"

if [[ "$OS_ID" == "centos" && "$OS_VERSION_ID" =~ ^(7|8)$ ]]; then
    log "系统版本符合要求：CentOS $OS_VERSION_ID"
elif [[ "$OS_ID" == "rocky" && "$OS_VERSION_ID" =~ ^9 ]]; then
    log "系统版本符合要求：Rocky Linux $OS_VERSION_ID"
else
    echo -e "\e[33m当前系统为 $OS_ID $OS_VERSION_ID，未在支持列表中。\e[0m"
    read -p $'\e[33m是否继续安装？(y/n): \e[0m' choice
    [[ ! "$choice" =~ ^[Yy]$ ]] && error_exit "已取消安装。"
fi

if [[ ! "$KERNEL_VER" =~ ^(3\.10\.0|4\.18\.0|5\.14\.0)- ]]; then
    echo -e "\e[33m当前内核版本为 $KERNEL_VER，未在推荐版本中。\e[0m"
    read -p $'\e[33m是否继续安装？(y/n): \e[0m' choice
    [[ ! "$choice" =~ ^[Yy]$ ]] && error_exit "已取消安装。"
else
    log "内核版本符合要求：$KERNEL_VER"
fi

# 检查并禁用 SELinux
log "检测 SELinux 状态..."
SELINUX_STATUS=$(getenforce 2>/dev/null || echo "Disabled")

if [[ "$SELINUX_STATUS" == "Enforcing" || "$SELINUX_STATUS" == "Permissive" ]]; then
    log "当前 SELinux 状态为 $SELINUX_STATUS，将临时设置为 Disabled"
    setenforce 0 || log "⚠️ 无法使用 setenforce 关闭 SELinux，可能未安装或非运行时可修改"

    if grep -q '^SELINUX=' /etc/selinux/config; then
        sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config
        log "已修改 /etc/selinux/config，禁用 SELinux（需重启生效）"
    else
        log "⚠️ 未找到 /etc/selinux/config 或配置不规范，请手动确认是否完全禁用 SELinux"
    fi
else
    log "SELinux 已处于关闭状态：$SELINUX_STATUS"
fi

# 3. 检查是否重复安装版本
log "检查当前系统已安装的 OpenSSH 版本..."
CURRENT_VER=$(rpm -q --qf '%{VERSION}-%{RELEASE}\n' openssh-server 2>/dev/null || echo "none")
TARGET_VER=$(rpm -q --qf '%{VERSION}-%{RELEASE}\n' -p openssh-server-*.rpm | head -n1)

if [[ "$CURRENT_VER" == "$TARGET_VER" ]]; then
    echo -e "\e[33m当前系统已安装相同版本（$CURRENT_VER），无需重复安装。\e[0m"
    read -p $'\e[33m是否强制安装此版本？(y/n): \e[0m' choice
    [[ ! "$choice" =~ ^[Yy]$ ]] && error_exit "已取消安装。"
fi

# 4. 备份流程
log "开始备份流程..."
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
BACKUP_DIR="/opt/openssh_backup_$TIMESTAMP"
mkdir -p "$BACKUP_DIR"

# 备份关键配置文件
log "备份关键配置文件..."
CRITICAL_FILES=(
    /etc/ssh/sshd_config
    /etc/ssh/ssh_config
    /etc/pam.d/sshd
)

for file in "${CRITICAL_FILES[@]}"; do
    if [[ -f "$file" ]]; then
        cp -a "$file" "$BACKUP_DIR/"
        log "已备份：$file"
    else
        log "⚠️ 未找到：$file"
    fi
done

# 备份整个/etc/ssh目录
if [[ -d "/etc/ssh" ]]; then
    log "备份整个/etc/ssh目录..."
    cp -a /etc/ssh "$BACKUP_DIR/etc_ssh"
    
    # 记录权限和ACL
    getfacl -R /etc/ssh > "$BACKUP_DIR/etc_ssh_acls.txt" 2>/dev/null
    find /etc/ssh -exec ls -la {} \; > "$BACKUP_DIR/etc_ssh_filelist.txt" 2>/dev/null
    log "已备份/etc/ssh目录权限和ACL信息"

fi

# 备份服务文件
log "备份服务相关文件..."
INIT_SYSTEM=$(cat /proc/1/comm)
log "检测到系统使用的初始化进程为：$INIT_SYSTEM"

SERVICE_FILES=(
    /etc/systemd/system/sshd.service
    /usr/lib/systemd/system/sshd.service
    /etc/rc.d/init.d/sshd
    /etc/init.d/sshd
)

for service_file in "${SERVICE_FILES[@]}"; do
    if [[ -f "$service_file" ]]; then
        cp -a "$service_file" "$BACKUP_DIR/"
        log "已备份服务文件：$service_file"
    fi
done

# 动态获取二进制路径函数
get_binary_path() {
    local name=$1
    # 尝试通过which查找
    local path=$(command -v "$name" 2>/dev/null)
    [[ -n "$path" ]] && { echo "$path"; return 0; }

    # 通过rpm查询openssh相关包
    local rpm_files=$(rpm -ql openssh-server openssh-clients openssh 2>/dev/null | grep -E "/${name}$")
    [[ -n "$rpm_files" ]] && { echo "$rpm_files" | head -n1; return 0; }

    # 常见默认路径回退
    case "$name" in
        sshd)        echo "/usr/sbin/sshd" ;;
        ssh)         echo "/usr/bin/ssh" ;;
        scp)         echo "/usr/bin/scp" ;;
        sftp)        echo "/usr/bin/sftp" ;;
        ssh-keygen)  echo "/usr/bin/ssh-keygen" ;;
        sftp-server) echo "/usr/libexec/openssh/sftp-server" ;;
        *)           echo ""
    esac
}

# 备份二进制文件（动态获取路径）
log "备份二进制文件和库..."
BINARIES=()
BINARY_NAMES=(sshd ssh scp sftp ssh-keygen sftp-server)

for binary_name in "${BINARY_NAMES[@]}"; do
    path=$(get_binary_path "$binary_name")
    if [[ -e "$path" || -L "$path" ]]; then
        BINARIES+=("$path")
        log "定位到二进制文件：$binary_name → $path"
    else
        log "⚠️ 未找到二进制文件：$binary_name"
    fi
done

# 添加其他可能的手动检查路径
EXTRA_PATHS=(
    /usr/libexec/openssh/ssh-keysign
    /usr/libexec/openssh/ssh-pkcs11-helper
)
for path in "${EXTRA_PATHS[@]}"; do
    [[ -e "$path" ]] && BINARIES+=("$path")
done

# 执行备份
for binary in "${BINARIES[@]}"; do
    if [[ -f "$binary" || -L "$binary" ]]; then
        mkdir -p "$BACKUP_DIR/$(dirname "$binary")"
        cp -a "$binary" "$BACKUP_DIR/$binary"
        log "已备份：$binary"
    fi
done

# 记录已安装的RPM包
log "记录已安装的RPM包信息..."
rpm -qa --queryformat '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\n' openssh\* > "$BACKUP_DIR/installed_rpms.txt"
rpm -qa --queryformat '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\n' > "$BACKUP_DIR/all_installed_rpms.txt"

# 验证备份完整性
log "验证备份完整性..."
BACKUP_VERIFICATION_FAILED=0
[[ ! -f "$BACKUP_DIR/etc_ssh/sshd_config" ]] && { log "⚠️ 关键文件sshd_config备份失败"; BACKUP_VERIFICATION_FAILED=1; }
[[ ! -f "$BACKUP_DIR/installed_rpms.txt" ]] && { log "⚠️ RPM包信息备份失败"; BACKUP_VERIFICATION_FAILED=1; }

if [[ $BACKUP_VERIFICATION_FAILED -eq 1 ]]; then
    echo -e "\e[31m备份验证失败！关键文件未成功备份。\e[0m"
    read -p $'\e[31m是否强制继续？(y/n): \e[0m' choice
    [[ ! "$choice" =~ ^[Yy]$ ]] && error_exit "安装中止，备份验证未通过。"
fi

log "备份完成，路径：$BACKUP_DIR"

# 5. 安装OpenSSH包
log "开始安装 OpenSSH 包..."
PACKAGES=$(find . -type f \( -name "openssh-*.rpm" -o -name "openssh-*.deb" \))
[[ -z "$PACKAGES" ]] && error_exit "找不到 openssh 安装包！"

# 记录安装前状态
log "记录系统当前状态..."
PRE_INSTALL_STATE=$(mktemp -d)
BACKUP_PKG_LIST="$PRE_INSTALL_STATE/pkg.list"

# 根据包管理器记录状态
if command -v rpm &>/dev/null; then
    rpm -qa --queryformat '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\n' > "$BACKUP_PKG_LIST"
elif command -v dpkg &>/dev/null; then
    dpkg -l | awk '/^ii/ {print $2"=" $3}' > "$BACKUP_PKG_LIST"
else
    error_exit "不支持的包管理器"
fi

# 安装过程
log "即将安装的包："
echo "$PACKAGES" | while read -r pkg; do
    log "  $(basename "$pkg")"
done

set +e
if command -v yum &>/dev/null; then
    log "使用 yum 安装..."
    yum localinstall -y $PACKAGES >>"$LOGFILE" 2>&1
elif command -v dpkg &>/dev/null; then
    log "使用 dpkg 安装..."
    dpkg -i $PACKAGES >>"$LOGFILE" 2>&1
    # 自动处理依赖
    apt-get -f install -y >>"$LOGFILE" 2>&1
fi
INSTALL_STATUS=$?
set -e

# 安装失败处理
if [[ $INSTALL_STATUS -ne 0 ]]; then
    echo -e "\e[31m安装失败，开始执行回退...\e[0m"
    
    # 包回退逻辑
    log "回退软件包变更..."
    if command -v rpm &>/dev/null; then
        # RPM 回退
        CURRENT_RPMS=$(mktemp)
        rpm -qa --queryformat '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\n' > "$CURRENT_RPMS"
        NEWLY_INSTALLED=$(comm -13 "$BACKUP_PKG_LIST" "$CURRENT_RPMS" | cut -d- -f1 | sort -u)
        for pkg in $NEWLY_INSTALLED; do
            rpm -e --nodeps "$pkg" && log "已卸载 $pkg" || log "卸载 $pkg 失败"
        done
        rm -f "$CURRENT_RPMS"
    elif command -v dpkg &>/dev/null; then
        # DEB 回退
        CURRENT_DEBS=$(mktemp)
        dpkg -l | awk '/^ii/ {print $2"=" $3}' > "$CURRENT_DEBS"
        NEWLY_INSTALLED=$(comm -13 "$BACKUP_PKG_LIST" "$CURRENT_DEBS" | cut -d= -f1)
        for pkg in $NEWLY_INSTALLED; do
            dpkg --purge "$pkg" && log "已卸载 $pkg" || log "卸载 $pkg 失败"
        done
        # 恢复自动安装的依赖
        apt-get autoremove -y >>"$LOGFILE" 2>&1
        rm -f "$CURRENT_DEBS"
    fi
    
    # 配置文件恢复增强
    log "恢复配置文件..."
    if [[ -d "$BACKUP_DIR/etc_ssh" ]]; then
        # 安全删除并恢复
        rm -rf /etc/ssh.rollback
        mv /etc/ssh /etc/ssh.rollback
        cp -a "$BACKUP_DIR/etc_ssh" /etc/ssh
        
        # 权限恢复
        if [[ -f "$BACKUP_DIR/etc_ssh_acls.txt" ]]; then
            log "恢复ACL权限..."
            setfacl --restore="$BACKUP_DIR/etc_ssh_acls.txt" 2>/dev/null || :
        fi
        
        log "恢复文件时间戳..."
while IFS= read -r line; do
    file=$(echo "$line" | awk '{print $NF}')  # 使用最后一个字段，支持路径中有空格的情况
    timestamp=$(echo "$line" | awk '{print $6" "$7" "$8}')
    echo "恢复 $file 到 $timestamp"
    touch -d "$timestamp" "$file" 2>/dev/null || true
done < "$BACKUP_DIR/etc_ssh_filelist.txt"

    fi
    
    # 服务文件恢复优化
    log "恢复服务文件..."
    mapfile -t SERVICE_FILES < <(find "$BACKUP_DIR" -type f \( -path "*/sshd.service" -o -path "*/sshd.init" \))
    for backup_file in "${SERVICE_FILES[@]}"; do
        target_file="/${backup_file#$BACKUP_DIR/}"
        mkdir -p "$(dirname "$target_file")"
        if cp -a "$backup_file" "$target_file"; then
            log "已恢复服务文件：$target_file"
        else
            log "⚠️ 恢复失败：$target_file"
        fi
    done
    
    # 二进制文件恢复强化
    log "恢复二进制文件..."
    while IFS= read -r binary; do
        src_path="$BACKUP_DIR/$binary"
        dest_path="/$binary"
        if [[ -f "$src_path" ]]; then
            mkdir -p "$(dirname "$dest_path")"
            if cp -a "$src_path" "$dest_path"; then
                log "已恢复二进制文件：$dest_path"
                # 恢复动态库依赖
                if ldd "$dest_path" &>/dev/null; then
                    ldd "$dest_path" | awk '/=> \// {print $3}' | while read -r lib; do
                        lib_src="$BACKUP_DIR/libs/${lib#/}"
                        if [[ -f "$lib_src" ]]; then
                            mkdir -p "$(dirname "$lib")"
                            cp -a "$lib_src" "$lib" && log "已恢复库文件：$lib"
                        fi
                    done
                fi
            fi
        fi
    done < <(find "$BACKUP_DIR/usr" -type f -executable)
    
    # 系统重载优化
    log "重新加载系统配置..."
    case "$INIT_SYSTEM" in
        systemd)
            systemctl daemon-reexec
            systemctl daemon-reload
            ;;
        init)
            service sshd reload
            ;;
        *)
            /etc/init.d/sshd reload
            ;;
    esac
    
    # 服务状态检查
    log "验证服务状态..."
    if command -v sshd &>/dev/null; then
        if systemctl is-active sshd &>/dev/null || pgrep sshd &>/dev/null; then
            log "SSH服务正在运行"
        else
            log "尝试启动SSH服务..."
            if systemctl start sshd || service sshd start || /etc/init.d/sshd start; then
                log "SSH服务启动成功"
            else
                log "⚠️ SSH服务启动失败，请手动检查"
            fi
        fi
    else
        log "⚠️ sshd 二进制文件不存在"
    fi
    
    error_exit "已完成回滚操作，OpenSSH安装失败，系统已恢复原状。"
fi

rm -rf "$PRE_INSTALL_STATE"

# 6. 配置修复与权限修复
log "验证配置并修复SSH密钥文件权限..."
SSHD_CONFIG="/etc/ssh/sshd_config"

[[ -f "$SSHD_CONFIG" ]] && sed -i '/^StrictScpCheck/d' "$SSHD_CONFIG"

# 检查并追加必要的SSH配置项
log "检查SSH登录配置项..."
missing_config=0

grep -qE '^\s*PermitRootLogin\s+yes' "$SSHD_CONFIG" || {
    log "缺少PermitRootLogin yes，正在添加..."
    echo "PermitRootLogin yes" >> "$SSHD_CONFIG"
    missing_config=1
}

grep -qE '^\s*PasswordAuthentication\s+yes' "$SSHD_CONFIG" || {
    log "缺少PasswordAuthentication yes，正在添加..."
    echo "PasswordAuthentication yes" >> "$SSHD_CONFIG"
    missing_config=1
}

[[ $missing_config -eq 1 ]] && log "SSH配置已补充，请确认安全策略是否允许。"

# 修复SSH主机密钥权限
log "修复SSH主机密钥权限..."
for key in /etc/ssh/ssh_host_*; do
    if [[ -f "$key" ]]; then
        chmod 600 "$key"
        log "已修复权限：$key"
    fi
done

# 验证配置是否正确
if sshd -t; then
    log "配置验证通过，重启服务..."
    systemctl daemon-reexec
    systemctl daemon-reload
    systemctl restart sshd
else
    error_exit "配置验证失败，请手动检查 $SSHD_CONFIG。"
fi

# 7. 显示状态与日志位置
systemctl status sshd --no-pager
log "🎉 SSH安装成功！备份路径：$BACKUP_DIR"
log "📄 安装日志保存在：$LOGFILE"